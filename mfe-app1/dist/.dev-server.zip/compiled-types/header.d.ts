import "./header.css";
export default function myheader(): import("react/jsx-runtime").JSX.Element;
